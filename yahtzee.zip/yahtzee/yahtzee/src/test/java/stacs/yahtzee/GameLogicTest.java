package stacs.yahtzee;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class GameLogicTest {
    private GameLogic game;
    private Player nina;

    @BeforeEach
    public void setup() {
        nina = new Player("Nina", 0);
        game = new GameLogic(nina);
    }

    @Test
    public void GameExists() {
        assertNotNull(game);
    }

    @Test
    public void PossibleUpperCombinations() {
        int[] dieArr = {1, 3, 4, 1, 2};
        boolean[] combinationsPossible = game.GameRules(dieArr);
        assertTrue(combinationsPossible[0]);
        assertTrue(combinationsPossible[1]);
        assertTrue(combinationsPossible[2]);
        assertTrue(combinationsPossible[3]);
        assertFalse(combinationsPossible[4]);
        assertFalse(combinationsPossible[5]);
    }

    @Test
    public void PossibleLowerCombinations() {
        int[] testArr1 = {1, 3, 4, 5, 2};
        assertTrue(game.GameRules(testArr1)[9]);
        assertTrue(game.GameRules(testArr1)[10]);
        assertFalse(game.GameRules(testArr1)[6]);
        assertFalse(game.GameRules(testArr1)[7]);
        assertFalse(game.GameRules(testArr1)[8]);
        assertTrue(game.GameRules(testArr1)[11]);
        assertFalse(game.GameRules(testArr1)[12]);

        int[] testArr2 = {3, 6, 5, 4, 6};
        assertTrue(game.GameRules(testArr2)[9]);
        assertFalse(game.GameRules(testArr2)[10]);
        assertFalse(game.GameRules(testArr2)[6]);

        int[] testArr3 = {5, 3, 5, 3, 5};
        assertTrue(game.GameRules(testArr3)[6]);
        assertTrue(game.GameRules(testArr3)[8]);
        assertFalse(game.GameRules(testArr3)[7]);

        int[] testArr4 = {1, 2, 2, 2, 2};
        assertTrue(game.GameRules(testArr4)[6]);
        assertTrue(game.GameRules(testArr4)[7]);
        assertFalse(game.GameRules(testArr4)[9]);

        int[] testArr5 = {1, 6, 1, 1, 3};
        assertTrue(game.GameRules(testArr5)[6]);
        assertFalse(game.GameRules(testArr5)[7]);
        assertFalse(game.GameRules(testArr5)[9]);

        int[] testArr6 = {4, 4, 4, 4, 4};
        assertTrue(game.GameRules(testArr6)[12]);
        assertTrue(game.GameRules(testArr6)[6]);
        assertTrue(game.GameRules(testArr6)[7]);
        assertFalse(game.GameRules(testArr6)[10]);

        int[] testArr7 = {6, 6, 5, 6, 2};
        assertTrue(game.GameRules(testArr7)[6]);
        assertFalse(game.GameRules(testArr7)[7]);
        assertFalse(game.GameRules(testArr7)[9]);
    }

    @Test
    public void AlreadyUsedCombinations() {
        int[] dieArr = {1, 3, 4, 1, 2};
        nina.FillOption(0);
        nina.FillOption(3);
        nina.FillOption(9);
        assertFalse(game.GameRules(dieArr)[0]);
        assertFalse(game.GameRules(dieArr)[3]);
        assertTrue(game.GameRules(dieArr)[1]);
        assertTrue(game.GameRules(dieArr)[2]);
        assertFalse(game.GameRules(dieArr)[9]);
        assertTrue(game.GameRules(dieArr)[11]);
    }

    @Test
    public void TestUnfilledOptions() {
        nina.FillOption(3);
        nina.FillOption(6);
        nina.FillOption(8);
        nina.FillOption(12);
        nina.FillOption(4);
        ArrayList<Integer> unfilled = game.UnfilledOptions();
        assertTrue(unfilled.contains(5));
        assertTrue(unfilled.contains(1));
        assertTrue(unfilled.contains(11));
        assertFalse(unfilled.contains(4));
        assertFalse(unfilled.contains(12));
    }

    @Test
    public void SelectingCombinationNotPossible() {
        int[] dieArr = {1, 3, 4, 5, 1};
        boolean[] options = game.GameRules(dieArr);
        int result = game.ScoreBoard(10, options, dieArr);
        assertEquals(0, result);
    }

    @Test
    public void BadOptionSelected() {
        nina.FillOption(5);
        int[] dieArr = {6, 4, 2, 6, 4};
        boolean[] options = game.GameRules(dieArr);
        assertThrows(IllegalArgumentException.class, () -> game.ScoreBoard(5, options, dieArr));
    }

    @Test
    public void TestScoreBoard() {

        int[] testArr1 = {1, 3, 4, 1, 2};
        boolean[] options = game.GameRules(testArr1);
        int result = game.ScoreBoard(10, options, testArr1);
        assertEquals(0, result);

        result = game.ScoreBoard(9, options, testArr1);
        assertEquals(30, result);


        int[] testArr2 = {3, 2, 2, 3, 3};
        options = game.GameRules(testArr2);
        result = game.ScoreBoard(1, options, testArr2);
        assertEquals(34, result);

        result = game.ScoreBoard(8, options, testArr2);
        assertEquals(59, result);

        result = game.ScoreBoard(6, options, testArr2);
        assertEquals(72, result);


        //Below test verifies that already filled option cannot be chosen
        assertThrows(IllegalArgumentException.class, () -> game.ScoreBoard(10, game.GameRules(testArr2), testArr2));
    }

    @Test
    public void TestBonus() {
        int[] testArr1 = {1, 3, 4, 1, 1};
        boolean[] options = game.GameRules(testArr1);
        int result = game.ScoreBoard(0, options, testArr1);
        assertEquals(3, result);

        int[] testArr2 = {2, 3, 2, 2, 2};
        options = game.GameRules(testArr2);
        result = game.ScoreBoard(1, options, testArr2);
        assertEquals(11, result);

        int[] testArr3 = {3, 3, 5, 6, 3};
        options = game.GameRules(testArr3);
        result = game.ScoreBoard(2, options, testArr3);
        assertEquals(20, result);

        int[] testArr4 = {4, 4, 5, 4, 4};
        options = game.GameRules(testArr4);
        result = game.ScoreBoard(3, options, testArr4);
        assertEquals(36, result);

        int[] testArr5 = {5, 5, 5, 2, 1};
        options = game.GameRules(testArr5);
        result = game.ScoreBoard(4, options, testArr5);
        assertEquals(51, result);

        int[] testArr6 = {6, 3, 6, 6, 3};
        options = game.GameRules(testArr6);
        int UpperSectionResult = game.ScoreBoard(5, options, testArr6);
        assertEquals(104, UpperSectionResult);

        /* Below test was written to test the bonus score condition
        int[] testArr6 = {6, 3, 2, 1, 3};
        options = game.GameRules(testArr6);
        int UpperSectionResult = game.ScoreBoard(5, options, testArr6);
        assertEquals(57, UpperSectionResult);
        */
    }

}
