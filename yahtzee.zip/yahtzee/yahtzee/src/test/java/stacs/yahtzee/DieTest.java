package stacs.yahtzee;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;

public class DieTest {

    private Die die;
    int[] initialValues;
    int[] sortedValues;
    int[] reRolledValues;
    boolean isSorted = true;

    @BeforeEach
    public void setup() {
        die = new Die();
        initialValues = Arrays.stream(die.InitialDieRoll()).toArray();  // gets the value from initial rolling of die and stores them as an array
    }

    @Test
    public void TestInitialRoll() {
        assertNotNull(initialValues);    // checks if the values from first rolling of die are being returned
    }

    @Test
    public void TestSortedCombination() {
        sortedValues = die.sortCombination(initialValues);
        for(int i=0; i<4; i++) {
            if(!(sortedValues[i+1] >= sortedValues[i]))    // checks the die values have been sorted
            {
                isSorted = false;
                break;
            }
        }
        assertTrue(isSorted);
    }

    @Test
    public void TestReRollOfDies() {
        reRolledValues = Arrays.stream(die.ReRollSomeDie(1, 1, 0, 0, 1, 2)).toArray();
        assertNotNull(reRolledValues);
        assertNotEquals(reRolledValues, initialValues);
        assertEquals(reRolledValues[2], initialValues[2]);
        assertEquals(reRolledValues[3], initialValues[3]);
    }

    @Test
    public void reRollBad() {
        assertThrows(IllegalArgumentException.class, () -> die.ReRollSomeDie(1, -1, 0, 1, 1, 1));
        assertThrows(IllegalArgumentException.class, () -> die.ReRollSomeDie(1, 4, 0, 1, 1, 1));
    }

    @Test
    public void reRollChancesOver() {
        assertThrows(IllegalArgumentException.class, () -> die.ReRollSomeDie(1, 0, 1, 1, 1, 3));
    }

}
