package stacs.yahtzee;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

public class PlayerTest {

    private Player john;
    private Player nina;
    private Player paul;
    int selectedOptionsCount = 0;

    @BeforeEach
    public void setup() {
        john = new Player("John", 0);
        nina = new Player("Nina", 1);
        paul = new Player("Paul", 2);
    }

    @Test
    public void testPlayerExists() {
        assertNotNull(john);
        assertNotNull(nina);
        assertNotNull(paul);
    }

    @Test
    public void testGetName() {
        assertEquals("John", john.getName());
        assertEquals("Nina", nina.getName());
        assertEquals("Paul", paul.getName());
    }

    @Test
    public void testGetPlayerNumber() {
        assertEquals(0, john.getPlayerNumber());
        assertEquals(1, nina.getPlayerNumber());
        assertEquals(2, paul.getPlayerNumber());
    }

    @Test
    public void testHasWonFalse() {
        assertFalse(nina.hasWon());
    }

    @Test
    public void testHasWonTrue() {
        nina.winGame();
        assertTrue(nina.hasWon());
    }

    @Test
    public void fillOptionForPlayer() {
        nina.FillOption(10);
        selectedOptionsCount++;
        nina.FillOption(12);
        selectedOptionsCount++;
        ArrayList<Integer> filledOptions = nina.getSelected();
        assertEquals(selectedOptionsCount, filledOptions.size());   //verifies that all the options selected are getting updated in the list of filled options
        assertEquals(Double.valueOf(10), Double.valueOf(filledOptions.get(0)));  //verifies that the option selected is correctly updated in the list of filled options
    }

    @Test
    public void BadOptionSelected() {    // checks that option selected by player for scoring exists
        assertThrows(IllegalArgumentException.class, () -> nina.FillOption(15));
    }

    @Test
    public void OptionAlreadyUsed() {    // checks if the selected option is already filled
        nina.FillOption(10);
        assertThrows(IllegalArgumentException.class, () -> nina.FillOption(10));
    }
}
