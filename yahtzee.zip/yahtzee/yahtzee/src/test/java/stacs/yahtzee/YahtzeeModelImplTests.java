package stacs.yahtzee;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

/**
 * 
 */
public class YahtzeeModelImplTests {
  
  private YahtzeeModelImpl yahtzee;
  ArrayList<Player> player;
  private Player john;
  private Player nina;
  private Player paul;
  private Player turnOfThePlayer;
  private ArrayList<Player> winners;
  private int[] finalScores;

  @BeforeEach
  public void setup() {
      yahtzee = new YahtzeeModelImpl();
      this.player = new ArrayList<>();
      this.finalScores = new int[100];
      john = new Player("John", 0);
      nina = new Player("Nina", 1);
      paul = new Player("Paul", 2);
      player.add(john);
      player.add(nina);
      player.add(paul);
      yahtzee.YahtzeeModelImpl(player.size(), player);
  }

    @Test
    public void turnOfNonExistingPlayer() {
        assertThrows(IllegalArgumentException.class, () -> turnOfThePlayer = yahtzee.turnTaking(6));
    }

    @Test
    public void testTurnsOver() {
      if(yahtzee.roundOngoing > 13) {
          assertEquals(null, yahtzee.turnTaking(0));
      }
    }

    @Test
    public void testTurnTaking() {

      if(yahtzee.roundOngoing <= 13) {
          turnOfThePlayer = yahtzee.turnTaking(0);
          assertNotNull(player);
          assertNotEquals(paul, turnOfThePlayer);
          assertEquals(john, turnOfThePlayer);

          turnOfThePlayer = yahtzee.turnTaking(1);
          assertEquals(nina, turnOfThePlayer);
          assertNotEquals(john, turnOfThePlayer);

          turnOfThePlayer = yahtzee.turnTaking(2);
          assertNotEquals(nina, turnOfThePlayer);
          assertEquals(paul, turnOfThePlayer);
          assertNotEquals(john, turnOfThePlayer);

          turnOfThePlayer = yahtzee.turnTaking(0);
          turnOfThePlayer = yahtzee.turnTaking(1);
          turnOfThePlayer = yahtzee.turnTaking(2);
          turnOfThePlayer = yahtzee.turnTaking(1);
          assertEquals(3, yahtzee.roundOngoing);
      }
    }

    @Test
    void testRepeatedTurnTaking() {
        turnOfThePlayer = yahtzee.turnTaking(2);
        assertEquals(paul, turnOfThePlayer);
        assertThrows(IllegalArgumentException.class, () -> turnOfThePlayer = yahtzee.turnTaking(2));
    }

    @Test
    void findWinner() {
        paul.finalScore(209);
        john.finalScore(209);
        nina.finalScore(187);
        finalScores[0] = john.getFinalScore();
        finalScores[1] = nina.getFinalScore();
        finalScores[2] = paul.getFinalScore();
        winners = yahtzee.outcome(finalScores);
        assertTrue(winners.contains(john));
        assertTrue(winners.contains(paul));
    }
}
