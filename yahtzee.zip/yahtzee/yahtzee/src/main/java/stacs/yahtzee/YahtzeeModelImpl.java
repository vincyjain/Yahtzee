package stacs.yahtzee;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * This is the implementation of turn taking among the multiple players and determination of winner
 */
public class YahtzeeModelImpl implements YahtzeeModel {

    ArrayList<Player> player;
    int totalPlayers;
    int roundOngoing = 1;     // flag for checking the ongoing round number as there have to be exactly 13 rounds for game to be finished
    int flag_for_roundCompletion = 0;  // flag for checking that one round has been completed after each player have played their turn
    ArrayList<Integer> chance_per_turn;  // for checking that each player plays only once per round
    int winningScore = 0;
    ArrayList<Player> winners;     // winners can be more than 1 in case of tie, as such a Collection of winners is required

    /**
    * Constructor.
    * @param player a collection of multiple players
    */
    public void YahtzeeModelImpl(int totalPlayers, ArrayList<Player> player) {
        this.totalPlayers = totalPlayers;
        this.player = player;
        this.chance_per_turn = new ArrayList<>();
        this.winners = new ArrayList<>();
    }

    /**
     * Gives turn to the particular player if the player has not already played for this round.
     * @return returns the player who has the current turn for testing purpose
     */
    public Player turnTaking(int playerNumber) {

        if(flag_for_roundCompletion == totalPlayers) {
            flag_for_roundCompletion = 0;
            chance_per_turn.clear();
            roundOngoing++;
        }
        if(playerNumber >= totalPlayers) {
            throw new IllegalArgumentException();
        }
        else if(roundOngoing > numberOfTurns) {
            return null;
        }
        else {
                return allow(playerNumber);
        }

    }

    /**
     * Checks if the player exists and has not already played their chance for this turn.
     */
    @Override
    public Player allow(int playerNumber) {
        Iterator it = player.iterator();
        while (it.hasNext()) {
            Player p;
            p = (Player) it.next();
            if (p.getPlayerNumber() == playerNumber) {
                if(chance_per_turn.contains(playerNumber)) {
                    throw new IllegalArgumentException();
                }
                else {
                    flag_for_roundCompletion++;
                    chance_per_turn.add(playerNumber);
                    return p;
                }
            }
        }
        return null;
    }

    /**
     * This method determines the winner of the game.
     * @param finalScores final scores of all the players after all rounds have finished
     * @return collection of winners
     */
    @Override
    public ArrayList<Player> outcome(int[] finalScores) {
        for (int i = 0; i < totalPlayers; i++) {
            if(winningScore < finalScores[i]) {
                winningScore = finalScores[i];
            }
        }
        Iterator it = player.iterator();
        while (it.hasNext()) {
            Player p;
            p = (Player) it.next();
            if(p.getFinalScore() == winningScore) {
                winners.add(p);
            }
        }
        return winners;
    }

}

