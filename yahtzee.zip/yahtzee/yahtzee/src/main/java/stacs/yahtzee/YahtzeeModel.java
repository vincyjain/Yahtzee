package stacs.yahtzee;

import java.util.ArrayList;

/**
 * Model implementation of Yahtzee game.
 * designed as an interface for dynamic handling at run time
 */
public interface YahtzeeModel {

 int numberOfTurns = 13;
 Player allow(int playerNumber);
 ArrayList<Player> outcome(int[] finalScores);

}
