package stacs.yahtzee;

import java.util.ArrayList;

/**
 * <p> Design decision : for making the handling of player easier,
 * many test cases call the Player class methods. </p>
 */
public class Player {

private final String name;
private final int playerNumber;
private final ArrayList<Integer> selected;   //list for storing already filled options
private boolean won;
private int score;

    /**
     * Constructor.
     * @param name name of the player
     * @param playerNumber number of the player
     */
    public Player(String name, int playerNumber) {
        this.name = name;
        this.playerNumber = playerNumber;
        this.selected = new ArrayList<>();
        this.won = false;
    }

    /**
     * Method used for getting player name.
     * @return name of the player
     */
    public String getName() {
        return this.name;
    }

    /**
     * Method used for getting number of the player
     * @return number of the player
     */
    public int getPlayerNumber() {
        return this.playerNumber;
    }

    /**
     * This method checks if the option requested to select for scoring is filled if not already filled.
     * @param optionNumber to fill this particular option
     */
    public void FillOption(int optionNumber) {
        if(selected.contains(optionNumber) || optionNumber < 0 || optionNumber > 12) {
            throw new IllegalArgumentException();
        }
        else {
            selected.add(optionNumber);
        }
    }

    /**
     * This method provides the list of already selected/filled options by the player.
     * @return list of already filled options
     */
    public ArrayList<Integer> getSelected() {
        return selected;
    }

    /**
     * Sets the flag that game has been won.
     */
    public void winGame() {
        won = true;
    }

    /**
     * Returns that game has been won.
     * @return won
     */
    public boolean hasWon() {
        return won;
    }

    /**
     * Sets the score of the player.
     */
    public void finalScore(int score) {
        this.score = score;
    }

    /**
     * Returns that score of the player.
     * @return score
     */
    public int getFinalScore() {
        return score;
    }

}
