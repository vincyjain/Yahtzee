package stacs.yahtzee;

import java.util.ArrayList;

/**
 * <p> Design decision : This class handles the rules of the game and the logic behind scoring.
 * Separate class for implementing the rules for simplification and testing edge cases. </p>
 */
public class GameLogic {

    Die die = new Die();
    protected Player player;
    int oneCount, twoCount, threeCount, fourCount, fiveCount, sixCount, consequentSequenceCount, sameValuesSequenceCount, previousCountOfConsequentValues, previousCountOfSameValues;
    boolean ones, twos, threes, fours, fives, sixes, three_of_a_kind, four_of_a_kind, full_house, small_straight, large_straight, chance, yahtzee;
    boolean[] possibleSelections = new boolean[13];
    ArrayList<Integer> unfilledOptions = new ArrayList<>();
    int score = 0;
    int sum_of_all_die = 0;
    int checkBonus = 0;
    int dummyVariable = 0;


    /**
     * Constructor.
     * @param player for checking the rules and scoring options for the particular player
     */
    public GameLogic(Player player) {
            this.player = player;
    }


    /**
     * This method implements all the rules of the game for scoring.
     * @param dieValues values of all 5 die after the last roll
     * @return possible combinations from the die values
     */
    public boolean[] GameRules(int dieValues[]) {

        oneCount = twoCount = threeCount = fourCount = fiveCount = sixCount = 0;
        consequentSequenceCount = sameValuesSequenceCount = previousCountOfConsequentValues = previousCountOfSameValues = 0;
        ones = twos = threes = fours = fives = sixes = three_of_a_kind = four_of_a_kind = full_house = small_straight = large_straight = chance = yahtzee = false;

        int[] sortedValues = die.sortCombination(dieValues);   // sorting the values of die for simplifying the determination of possible options

        for (int i = 0; i < 5; i++) {
            switch (sortedValues[i]) {
                case 1:
                    oneCount++;                                // number of die with 1 as the value
                    ones = !player.getSelected().contains(0);  // if the option is not filled already then mark this as true for list of possible selections
                    break;
                case 2:
                    twoCount++;
                    twos = !player.getSelected().contains(1);
                    break;
                case 3:
                    threeCount++;
                    threes = !player.getSelected().contains(2);
                    break;
                case 4:
                    fourCount++;
                    fours = !player.getSelected().contains(3);
                    break;
                case 5:
                    fiveCount++;
                    fives = !player.getSelected().contains(4);
                    break;
                case 6:
                    sixCount++;
                    sixes = !player.getSelected().contains(5);
                    break;
                default:
                    break;
            }
        }

        for(int i = 0; i < 4; i++) {
            if(sortedValues[i+1] - sortedValues[i] == 1) {
                consequentSequenceCount++;   // This count helps in determining if the sequence is formed
            }
            else {
                previousCountOfConsequentValues = consequentSequenceCount;   /* Example: {2, 1, 4, 5, 2}
                                      sorted values will be {1, 2, 2, 4, 5}
                                      seq value will be 1 when 1 and 2 are checked. Then for 2 and 2 this will go to else loop.
                                      As such value of seq needs to be saved in another variable so that seq can again used to
                                      check 4 and 5
                                    */
                consequentSequenceCount = 0;
            }
        }
        if(consequentSequenceCount == 3 || previousCountOfConsequentValues == 3) {  /* Condition1 : for sorted combinations like { 1, 3, 4, 5, 6} as after checking
                                               the last pair i.e. 5 and 6, the seq will not enter the else loop. So we need to check using the value of seq if a
                                               small straight can be formed.  Condition2 : for sorted combinations like {2, 3, 4, 5, 5} as for 5 and 5 seq will
                                               become 0 but countPrev will have the previous value of seq i.e. 3. So small_straight can be formed.
                                             */
            small_straight = !player.getSelected().contains(9);      // if not already filled mark as true
            consequentSequenceCount = 0;
        }
        else if(consequentSequenceCount == 4) {         /* Here the condition is checked using seq as the loop else will never be used if all five elements are
                                                           in sequence and hence countPrev value will remain zero */
            small_straight = !player.getSelected().contains(9);
            large_straight = !player.getSelected().contains(10);
            consequentSequenceCount = 0;
        }

        for(int i = 0; i < 4; i++) {
            if (sortedValues[i + 1] == sortedValues[i]) {
                sameValuesSequenceCount++;
            } else {
                previousCountOfSameValues = sameValuesSequenceCount;
                sameValuesSequenceCount = 0;
                if(previousCountOfSameValues == 2) {
                    dummyVariable = 2;  /* introduced for the edge case like {1, 1, 1, 3, 6}
                                           In such case values of previousCountOfSameValues and sameValuesSequenceCount will become zero after last iteration.
                                           So, the value of 3 same values has been stored in a dummy variable for three_of_a_kind sequence.
                                         */
                }
            }
        }
            if(sameValuesSequenceCount == 4) {       /* Here the condition is checked using seq as the loop else will never be used if all five values are same and
                                                        hence count value will remain zero */
                yahtzee = !player.getSelected().contains(12);
                four_of_a_kind = !player.getSelected().contains(7);
                three_of_a_kind = !player.getSelected().contains(6);
                sameValuesSequenceCount = 0;
            }
            else if(previousCountOfSameValues == 3 || sameValuesSequenceCount == 3) {
                four_of_a_kind = !player.getSelected().contains(7);
                three_of_a_kind = !player.getSelected().contains(6);
                previousCountOfSameValues = 0;
                sameValuesSequenceCount = 0;
            }
            else if(previousCountOfSameValues == 2) {                                    // Example: {3, 3, 3, 4, 6}
                three_of_a_kind = !player.getSelected().contains(6);
                if(sameValuesSequenceCount == 1) {                                       // Example: {2, 2, 2, 5, 5}
                    full_house = !player.getSelected().contains(8);
                    sameValuesSequenceCount = 0;
                }
                previousCountOfSameValues = 0;
            }
            else if(previousCountOfSameValues == 1) {
                if(sameValuesSequenceCount == 2) {                                       // Example: {1, 1, 4, 4, 4}
                    full_house = !player.getSelected().contains(8);
                    three_of_a_kind = !player.getSelected().contains(6);
                    sameValuesSequenceCount = 0;
                }
                previousCountOfSameValues = 0;
            }
            else if(sameValuesSequenceCount == 2) {                                      // Example: {2, 4, 6, 6, 6}
                three_of_a_kind = !player.getSelected().contains(6);
                sameValuesSequenceCount = 0;
            }
            else if(sameValuesSequenceCount == 0 && previousCountOfSameValues == 0 && dummyVariable == 2) {
                three_of_a_kind = !player.getSelected().contains(6);
                dummyVariable = 0;
            }

        chance = !player.getSelected().contains(11);      //if not already selected, chance will always be possible option

        return AvailableCombinations();
    }


    /**
     * Method decomposition for cleaner code.
     * @return all possible combinations with the set of die values
     */
    public boolean[] AvailableCombinations() {

        possibleSelections[0] = ones;
        possibleSelections[1] = twos;
        possibleSelections[2] = threes;
        possibleSelections[3] = fours;
        possibleSelections[4] = fives;
        possibleSelections[5] = sixes;
        possibleSelections[6] = three_of_a_kind;
        possibleSelections[7] = four_of_a_kind;
        possibleSelections[8] = full_house;
        possibleSelections[9] = small_straight;
        possibleSelections[10] = large_straight;
        possibleSelections[11] = chance;
        possibleSelections[12] = yahtzee;

        return possibleSelections;
    }


    /**
     * Answers the question of Empty options that can still be filled by the player.
     * @return list of empty/unfilled options
     */
    public ArrayList<Integer> UnfilledOptions() {
        for (int i = 0; i < 13; i++) {
            if(!player.getSelected().contains(i))
                unfilledOptions.add(i);
        }
        return unfilledOptions;
    }


    /**
     * </p> This method adds up the scores for all selected options till now.
     * The method also checks the possibility of gaining the bonus score. </p>
     * checkBonus is used to check the total score of the upper section.
     * @param choice option the user wants to fill up
     * @return total score obtained till last selected option.
     */
    public int ScoreBoard(int choice, boolean[] possibleSelections, int[] dieValues) {

        sum_of_all_die = dieValues[0] + dieValues[1] + dieValues[2] + dieValues[3] + dieValues[4];

        if(choice == 0) {
            if(possibleSelections[0]) {
                score += oneCount;
                checkBonus += oneCount;
            }
            player.FillOption(0);    //adds the chosen option to already filled options list
        }
        else if(choice == 1) {
            if(possibleSelections[1]) {
                score += (twoCount)*2;
                checkBonus += (twoCount)*2;
            }
            player.FillOption(1);
        }
        else if(choice == 2) {
            if(possibleSelections[2]) {
                score += (threeCount)*3;
                checkBonus += (threeCount)*3;
            }
            player.FillOption(2);
        }
        else if(choice == 3) {
            if(possibleSelections[3]) {
                score += (fourCount)*4;
                checkBonus += (fourCount)*4;
            }
            player.FillOption(3);
        }
        else if(choice == 4) {
            if(possibleSelections[4]) {
                score += (fiveCount)*5;
                checkBonus += (fiveCount)*5;
            }
            player.FillOption(4);
        }
        else if(choice == 5) {
            if(possibleSelections[5]) {
                score += (sixCount)*6;
                checkBonus += (sixCount)*6;
            }
            player.FillOption(5);
        }
        else if(choice == 6) {
            if(possibleSelections[6]) {
                score += sum_of_all_die;
            }
            player.FillOption(6);
        }
        else if(choice == 7) {
            if(possibleSelections[7]) {
                score += sum_of_all_die;
            }
            player.FillOption(7);
        }
        else if(choice == 8) {
            if(possibleSelections[8]) {
                score += 25;
            }
            player.FillOption(8);
        }
        else if(choice == 9) {
            if(possibleSelections[9]) {
                score += 30;
            }
            player.FillOption(9);
        }
        else if(choice == 10) {
            if(possibleSelections[10]) {
                score += 40;
            }
            player.FillOption(10);
        }
        else if(choice == 11) {
            if(possibleSelections[11]) {
                score += sum_of_all_die;
            }
            player.FillOption(11);
        }
        else if(choice == 12) {
            if(possibleSelections[12]) {
                score += 50;
            }
            player.FillOption(12);
        }

        if(checkBonus >= 63) {
            score += 35;
        }

        return score;
    }
}
