package stacs.yahtzee;
import java.util.Arrays;

 /**
  * Implementation of die rolling for Yahtzee game.
  * <p> This class rolls the die as per the turn requirements of the player and rules of the game.
  * Class designed for handling the test cases more precisely </p>
  */
public class Die {

    int die1, die2, die3, die4, die5;
    int[] combination = {0, 0, 0, 0, 0};

    /**
     * Roll all 5 die for the first chance of each turn
     */
    public int[] InitialDieRoll() {
        die1 = RollDie();
        die2 = RollDie();
        die3 = RollDie();
        die4 = RollDie();
        die5 = RollDie();
        combination[0] = die1;
        combination[1] = die2;
        combination[2] = die3;
        combination[3] = die4;
        combination[4] = die5;
        return combination;
    }

     /**
      * Invokes rolling of any die.
      * method is public as other functions are using this.
      */
    public int RollDie() {
        return (int)(Math.random()*6)+1;
    }

     /**
      * Rolls particular set of die again
      * @param reRollCount includes the count of die rolling chances already taken
      */
    public int[] ReRollSomeDie(int reRollDie1, int reRollDie2, int reRollDie3, int reRollDie4, int reRollDie5, int reRollCount) {

        if (reRollCount == 1 || reRollCount == 2) {     // only two chances of rolling die again
            switch (reRollDie1) {
                case 1:                 // for the die selected by the player to roll again, 1 will be entered as argument
                    combination[0] = RollDie(); //re-roll Die 1
                    break;
                case 0:                 // for the die selected by the player to keep the value, 0 will be entered as argument
                    break;
                default:
                    throw new IllegalArgumentException();  // if any value other than 0 or 1 have been entered as argument
            }

            switch (reRollDie2) {
                case 1:
                    combination[1] = RollDie();   //re-roll Die 2
                    break;
                case 0:
                    break;
                default:
                    throw new IllegalArgumentException();
            }

            switch (reRollDie3) {
                case 1:
                    combination[2] = RollDie();   //re-roll Die 3
                    break;
                case 0:
                    break;
                default:
                    throw new IllegalArgumentException();
            }

            switch (reRollDie4) {
                case 1:
                    combination[3] = RollDie();   //re-roll Die 4
                    break;
                case 0:
                    break;
                default:
                    throw new IllegalArgumentException();
            }

            switch (reRollDie5) {
                case 1:
                    combination[4] = RollDie();   //re-roll Die 5
                    break;
                case 0:
                    break;
                default:
                    throw new IllegalArgumentException();
            }
        }
        else {
            throw new IllegalArgumentException();
        }
        return combination;
    }

     /**
      * Sorts the array of values returned after rolling of the die
      */
    public int[] sortCombination(int[] combination) {
        int[] sortedDieValues = combination;
        Arrays.sort(combination);  // for sorting the values obtained from all 5 die
        return sortedDieValues;
    }

}